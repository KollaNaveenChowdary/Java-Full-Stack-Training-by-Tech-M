import 'package:flutter/material.dart';
import 'package:flutterapplicationtask/helpers/database_helper.dart';

class ContactPage extends StatefulWidget {
  @override
  _ContactPageState createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _messageController = TextEditingController();

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      Map<String, dynamic> contact = {
        'name': _nameController.text,
        'email': _emailController.text,
        'message': _messageController.text,
      };

      await DatabaseHelper.instance.insertContact(contact);

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Message Stored Successfully!')));

      _nameController.clear();
      _emailController.clear();
      _messageController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isDesktop = MediaQuery.of(context).size.width > 600;

    return Scaffold(
      appBar: AppBar(title: Text('Contact Us'), backgroundColor: Colors.green),
      body: Center(
        child: Container(
          width: isDesktop ? 500 : double.infinity,
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(labelText: 'Name'),
                  validator:
                      (value) => value!.isEmpty ? 'Enter your name' : null,
                ),
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(labelText: 'Email'),
                  keyboardType: TextInputType.emailAddress,
                  validator:
                      (value) =>
                          value!.isEmpty || !value.contains('@')
                              ? 'Enter a valid email'
                              : null,
                ),
                TextFormField(
                  controller: _messageController,
                  decoration: InputDecoration(labelText: 'Message'),
                  maxLines: 4,
                  validator:
                      (value) => value!.isEmpty ? 'Enter your message' : null,
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _submitForm,
                  child: Text('Send Message'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
