import 'package:flutter/material.dart';
import 'home_page.dart';
import 'about_page.dart';
import 'services_page.dart';
import 'blog_page.dart';
import 'contact_page.dart';
import 'package:flutterapplicationtask/helpers/database_helper.dart';

class ProductsPage extends StatefulWidget {
  @override
  _ProductsPageState createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _imageUrlController = TextEditingController();
  List<Map<String, dynamic>> _products = [];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    final db = await DatabaseHelper.instance.database;
    final products = await db.query('products');

    print("📦 Products Fetched: $products"); // Debugging Log

    setState(() {
      _products = products;
    });
  }

  Future<void> _addProduct() async {
    if (_nameController.text.isNotEmpty &&
        _priceController.text.isNotEmpty &&
        _imageUrlController.text.isNotEmpty) {
      final db = await DatabaseHelper.instance.database;
      await db.insert('products', {
        'name': _nameController.text,
        'price': _priceController.text,
        'imageUrl': _imageUrlController.text,
      });

      print(
        "✅ Product Added: ${_nameController.text}, ₹${_priceController.text}",
      ); // Debugging Log

      _nameController.clear();
      _priceController.clear();
      _imageUrlController.clear();

      _loadProducts(); // Refresh List
    } else {
      print("⚠️ Fields are empty. Product not added.");
    }
  }

  Future<void> _deleteProduct(int index) async {
    final db = await DatabaseHelper.instance.database;
    await db.delete(
      'products',
      where: 'id = ?',
      whereArgs: [_products[index]['id']],
    );

    print("🗑 Product Deleted: ${_products[index]['name']}"); // Debugging Log

    _loadProducts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Our Products'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Product Name'),
            ),
            TextField(
              controller: _priceController,
              decoration: InputDecoration(labelText: 'Product Price'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _imageUrlController,
              decoration: InputDecoration(labelText: 'Image URL'),
              keyboardType: TextInputType.url,
            ),
            SizedBox(height: 10),
            ElevatedButton(onPressed: _addProduct, child: Text("Add Product")),
            Expanded(
              child: ListView.builder(
                itemCount: _products.length,
                itemBuilder: (context, index) {
                  final product = _products[index];
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: Image.network(
                        product['imageUrl']!,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                      title: Text(product['name']!),
                      subtitle: Text("₹${product['price']}"),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteProduct(index),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
