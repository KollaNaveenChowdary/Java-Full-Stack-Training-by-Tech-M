import 'package:flutter/material.dart';
import 'about_page.dart';
import 'services_page.dart';
import 'blog_page.dart';
import 'contact_page.dart';
import 'products_page.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    bool isDesktop = MediaQuery.of(context).size.width > 600;

    return Scaffold(
      appBar: AppBar(
        title: Text('Agriculture Products'),
        backgroundColor: Colors.green,
        actions: isDesktop ? _buildNavButtons(context) : null,
      ),
      drawer:
          isDesktop
              ? null
              : Drawer(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    DrawerHeader(
                      decoration: BoxDecoration(color: Colors.green),
                      child: Text(
                        'Menu',
                        style: TextStyle(color: Colors.white, fontSize: 24),
                      ),
                    ),
                    ..._buildDrawerItems(context),
                  ],
                ),
              ),
      body: Center(
        child: Text(
          "Welcome to Our Agriculture Store",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  List<Widget> _buildNavButtons(BuildContext context) {
    return [
      _navButton(context, 'Home', HomePage()),
      _navButton(context, 'Products', ProductsPage()),
      _navButton(context, 'About Us', AboutPage()),
      _navButton(context, 'Services', ServicesPage()),
      _navButton(context, 'Blog', BlogPage()),
      _navButton(context, 'Contact', ContactPage()),
    ];
  }

  List<Widget> _buildDrawerItems(BuildContext context) {
    return [
      _drawerItem(context, 'Home', HomePage()),
      _drawerItem(context, 'Products', ProductsPage()),
      _drawerItem(context, 'About Us', AboutPage()),
      _drawerItem(context, 'Services', ServicesPage()),
      _drawerItem(context, 'Blog', BlogPage()),
      _drawerItem(context, 'Contact', ContactPage()),
    ];
  }

  Widget _navButton(BuildContext context, String title, Widget page) {
    return TextButton(
      onPressed:
          () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => page),
          ),
      child: Text(title, style: TextStyle(color: Colors.white)),
    );
  }

  Widget _drawerItem(BuildContext context, String title, Widget page) {
    return ListTile(
      title: Text(title),
      onTap:
          () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => page),
          ),
    );
  }
}
